﻿namespace TrabalhoIntegrador.Web.Services
{
    public class CatalogService
    {
    }
}
