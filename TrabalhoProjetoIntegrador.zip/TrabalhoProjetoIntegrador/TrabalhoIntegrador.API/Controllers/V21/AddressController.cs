﻿using Microsoft.AspNetCore.Mvc;
using ProjetoIntegrador.Application.Interfaces;
using ProjetoIntegrador.Application.ViewModel;

namespace ProjetoIntegrador.API.Controllers.V21
{
    [ApiController]
    [Route("api/v21/address")]
    public class AddressController : Controller
    {
        protected readonly IAddressAppService _addressAppService;

        public AddressController(IAddressAppService addressAppService)
        {
            _addressAppService = addressAppService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<AddressViewModel>> Get()
        {
            var result = _addressAppService.Search(a => true);

            return Ok(result);
        }

        [HttpGet("{id}")]
        public ActionResult<AddressViewModel> Get(Guid id)
        {
            var result = _addressAppService.GetById(id);
            return Ok(result);
        }

        [HttpPost]
        public ActionResult PostAsync([FromBody] AddressViewModel model)
        {
            var result = _addressAppService.Add(model);
            return Ok(result);
        }

        [HttpPut("{id}")]
        public ActionResult Put(Guid id, [FromBody] AddressViewModel model)
        {
            return Ok(_addressAppService.Update(model));
        }

        [HttpDelete("{id}")]
        public ActionResult Delete(Guid id)
        {
            _addressAppService.Remove(id);
            return Ok();
        }
    }
}
