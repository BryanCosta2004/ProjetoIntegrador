﻿using ProjetoIntegrador.Application.ViewModel;
using ProjetoIntegrador.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoIntegrador.Application.Interfaces
{
    public interface IClientAppService
    {
        ClientViewModel GetById(Guid id);
        IEnumerable<ClientViewModel> Search(Expression<Func<Client, bool>> expression);
        IEnumerable<ClientViewModel> Search(Expression<Func<Client, bool>> expression,
            int pageNumber,
            int pageSize);
        ClientViewModel Add(ClientViewModel viewModel);
        ClientViewModel Update(ClientViewModel viewModel);
        void Remove(Guid id);
        void Remove(Expression<Func<Client, bool>> expression);
        void SetAddAddressClient(Guid clientId, AddressViewModel address);
    }
}