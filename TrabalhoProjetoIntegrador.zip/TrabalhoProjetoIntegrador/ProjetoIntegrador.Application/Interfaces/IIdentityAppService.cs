﻿using ProjetoIntegrador.Application.DTOs.Request;
using ProjetoIntegrador.Application.DTOs.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoIntegrador.Application.Interfaces
{
    public interface IIdentityService
    {
        Task<UserRegisteredResponse> RegisterUser(UserRegisteredRequest request);
        Task<UserLoginResponse> Login(UserLoginRequest request);
    }
}
