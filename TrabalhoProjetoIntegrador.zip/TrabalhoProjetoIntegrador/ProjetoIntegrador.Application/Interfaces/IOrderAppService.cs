﻿using Microsoft.AspNetCore.Mvc;
using ProjetoIntegrador.Application.ViewModel;
using ProjetoIntegrador.Core.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoIntegrador.Application.Interfaces
{
    public interface IOrderAppService
    {
        
        OrderViewModel SetCreateNewOrder(OrderViewModel viewModel);
        IEnumerable<OrderItemViewModel> SetInsertNewItem(OrderItemViewModel model,
            Guid orderId);
        IEnumerable<OrderItemViewModel> DeleteItemInOrder(Guid orderItemId, Guid orderId);
        void UpdateQuantityItemInOrder(Guid orderItemId, int newQuantity);
        OrderViewModel UpdateStatusOrder(Guid orderId, OrderStatus newStatus);
        OrderViewModel SetAddressDelivery(Guid orderId, AddressViewModel addresViewModel);
        OrderViewModel SetApplyVoucher(Guid orderId, string code);
        ActionResult<OrderViewModel> GetLastOrderByClient(Guid clientId);
        ActionResult<OrderViewModel> GetById(Guid orderId);
        object GetOrdersByClient(Guid clientId);
    }
}
