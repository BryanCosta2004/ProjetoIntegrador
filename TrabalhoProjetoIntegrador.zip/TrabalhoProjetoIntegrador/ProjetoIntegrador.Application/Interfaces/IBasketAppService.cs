﻿using ProjetoIntegrador.Application.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoIntegrador.Application.Interfaces
{
    public interface IBasketAppService
    {
        
        BasketViewModel AddBasket(BasketViewModel viewModel);        
        BasketViewModel GetById(Guid id);        
        IEnumerable<BasketItemViewModel> AddItemBasket(BasketItemViewModel viewModel);       
        IEnumerable<BasketItemViewModel> RemoveItemBasket(Guid idBasketItem, Guid productId);        
        void UpdateItemQuantity(Guid idBasketItem, int quantity);        
        void ClearBasket(Guid basketId);

    }
}
