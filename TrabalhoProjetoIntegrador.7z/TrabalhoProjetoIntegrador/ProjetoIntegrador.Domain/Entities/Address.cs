﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoIntegrador.Domain.Entities
{
    public class Address
    {
        protected Address() { }
        public string Neighborhood { get; set; }
        public string Street { get; set; }
        public int City { get; set; }
        public string State { get; set; }
        public string Complement { get; set; }
        public string Country { get; set; }
        public string PostalCode { get; set; }
        public Guid Id { get; internal set; }
    }
}
