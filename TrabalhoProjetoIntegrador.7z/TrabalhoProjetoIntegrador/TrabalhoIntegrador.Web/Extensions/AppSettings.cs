﻿namespace TrabalhoIntegrador.Web.Extensions
{
    public class AppSettings
    {
        public string Url { get; set; }
    }
}
