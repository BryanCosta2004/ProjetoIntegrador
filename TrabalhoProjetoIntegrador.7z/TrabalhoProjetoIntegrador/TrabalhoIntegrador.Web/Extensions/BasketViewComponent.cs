﻿using Microsoft.AspNetCore.Mvc;

namespace TrabalhoIntegrador.Web.Extensions
{
    public class BasketViewComponent : ViewComponent
    {
        public BasketViewComponent()
        {

        }
    }
}
