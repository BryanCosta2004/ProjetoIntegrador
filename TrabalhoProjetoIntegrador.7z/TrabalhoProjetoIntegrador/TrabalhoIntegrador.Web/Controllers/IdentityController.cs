﻿namespace TrabalhoIntegrador.Web.Controllers
{
    public class IdentityController
    {
    }
}
