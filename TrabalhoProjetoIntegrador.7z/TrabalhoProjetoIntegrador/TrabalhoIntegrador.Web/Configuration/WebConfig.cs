﻿namespace TrabalhoIntegrador.Web.Configuration
{
    public class WebConfig
    {
    }
}
