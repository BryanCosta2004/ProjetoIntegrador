﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoIntegrador.Core.Enums
{
    public enum OrderStatus
    {
        Em_aprovação,
        Aprovado,
        Recusado,
        Entregue,
        Cancelado,
    }
}
