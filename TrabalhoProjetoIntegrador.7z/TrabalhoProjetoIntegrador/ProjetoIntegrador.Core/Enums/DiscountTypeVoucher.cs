﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoIntegrador.Core.Enums
{
    public enum DiscountTypeVoucher
    {
        Percentual = 0,
        Valor = 1
    }
}
